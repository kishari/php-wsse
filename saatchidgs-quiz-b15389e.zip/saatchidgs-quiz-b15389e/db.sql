CREATE TABLE `edit` (
  `id` int(4) NOT NULL auto_increment,
  `scores` varchar(225) NOT NULL,
  PRIMARY KEY  (`id`)
);

INSERT INTO `edit` VALUES (1, 1);
INSERT INTO `edit` VALUES (2, 2);
INSERT INTO `edit` VALUES (3, 5);